package youtube.samuel.info.youtubeesilvsamuel2.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
        import android.view.MenuInflater;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
        import android.widget.SearchView;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.StringRequest;
        import com.android.volley.toolbox.Volley;
        import com.google.gson.Gson;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import youtube.samuel.info.youtubeesilvsamuel2.Constants;
import youtube.samuel.info.youtubeesilvsamuel2.R;
import youtube.samuel.info.youtubeesilvsamuel2.adapters.VideoAdapter;
import youtube.samuel.info.youtubeesilvsamuel2.models.Video;

public class itemsActivity extends AppCompatActivity {

    //private static final String SEARCHRESULT_URL = "https://www.googleapis.com/youtube/v3/search?part=id&q=mika&type=video";

    ListView lv;
    Video videoObj;
    VideoAdapter adp;
    Gson gson;

    public static final String PREFS_NAME = "PingBusPrefs";
    public static final String PREFS_SEARCH_HISTORY = "SearchHistory";
    private SharedPreferences settings;
    private Set<String> history;

    private void setAutoCompleteSource()
    {
        AutoCompleteTextView editText1 = (AutoCompleteTextView) findViewById(R.id.editText);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, history.toArray(new String[history.size()]));
        editText1.setAdapter(adapter);
    }

    private void addSearchInput(String input)
    {
        if (!history.contains(input))
        {
            history.add(input);
            setAutoCompleteSource();
        }
    }

    private void savePrefs()
    {
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putStringSet(PREFS_SEARCH_HISTORY, history);

        editor.commit();
    }

    public itemsActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        lv = (ListView) findViewById(R.id.listvideo);
        requestData("");

        settings = getSharedPreferences(PREFS_NAME, 0);
        //history = settings.getStringSet(PREFS_SEARCH_HISTORY, new HashSet<String>());
        history=new HashSet<String>(settings.getStringSet(PREFS_SEARCH_HISTORY, new HashSet<String>()));

        setAutoCompleteSource();

        final AutoCompleteTextView editText1 = (AutoCompleteTextView) findViewById(R.id.editText);
        editText1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                    // Touche OK sélectionné.
                    addSearchInput(editText1.getText().toString());
                    Submit();

                }
                return false;
            }

            });


        final Button button = (Button) findViewById(R.id.Search);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                addSearchInput(editText1.getText().toString());
                Submit();
            }
        });


    }


public void Submit()
{

    final AutoCompleteTextView editText1 = (AutoCompleteTextView) findViewById(R.id.editText);
    // On récupère l'éditeur de texte
    String textRecupere=editText1.getText().toString();
    requestData(textRecupere);




    //Sear texterecupéré = editext.text.tostring
    //requestData(textRecupere);
}


    public String requestData(String edittext) {

        String data = edittext.replaceAll("\\s","+");
        String query="https://www.googleapis.com/youtube/v3/search?part=snippet&q='"+data+"'&type=video&videoCaption=closedCaption&key="+Constants.API_KEY;

        StringRequest request = new StringRequest(query, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Results", response);

                String httpget = new String(response);
                gson = new Gson();
                videoObj = gson.fromJson(httpget, Video.class);

                Log.d("Info", httpget);
                adp = new VideoAdapter(itemsActivity.this, videoObj.getItems());
                lv.setAdapter(adp);
                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        onItemSelected(videoObj.getItems().get(position));
                    }
                });





            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError response) {
//                Log.e("Results",response.getMessage());
            }
        });
        Volley.newRequestQueue(this).add(request);


        return edittext;
    }

    @Override
    protected void onStop()
    {
        super.onStop();

        savePrefs();
    }

    public void onItemSelected( Video.ItemsBean item) {
        videoActivity.start(this, item.getId().getVideoId());
        //startActivity(new Intent(StationsActivity.this, MapsActivity.class));
    }

    }






