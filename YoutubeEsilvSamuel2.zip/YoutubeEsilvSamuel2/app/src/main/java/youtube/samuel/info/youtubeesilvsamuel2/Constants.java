package youtube.samuel.info.youtubeesilvsamuel2;

/**
 * Created by sam88 on 20/03/2017.
 */

public class Constants {
    public static final String API_KEY = "AIzaSyCyhrnrKKd501TA7qKLPnxqMWTVppU0O-U";
}
