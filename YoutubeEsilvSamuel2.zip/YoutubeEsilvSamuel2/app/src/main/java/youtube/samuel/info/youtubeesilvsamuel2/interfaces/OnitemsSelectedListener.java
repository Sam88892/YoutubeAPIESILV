package youtube.samuel.info.youtubeesilvsamuel2.interfaces;

import youtube.samuel.info.youtubeesilvsamuel2.models.Video;

/**
 * Created by sam88 on 22/03/2017.
 */

public interface OnitemsSelectedListener {
    void OnItemSelected(Video.ItemsBean item);
}
