package youtube.samuel.info.youtubeesilvsamuel2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.List;

import youtube.samuel.info.youtubeesilvsamuel2.R;
import youtube.samuel.info.youtubeesilvsamuel2.models.Video;

/**
 * Created by sam88 on 21/03/2017.
 */

public class VideoAdapter extends BaseAdapter{

    private List<Video.ItemsBean> myVideos;
    private Context ct;
    private LayoutInflater inflater;

    public VideoAdapter(Context ct, List<Video.ItemsBean> myVideos)
    {
        this.ct = ct;
        this.myVideos =myVideos;
    }


    @Override
    public int getCount() {
        return myVideos.size();
    }

    @Override
    public Object getItem(int position) {
        return myVideos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View v, ViewGroup root){
        LayoutInflater inflater = (LayoutInflater) ct
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View listView = inflater.inflate(R.layout.list, root, false);



    Video.ItemsBean i = (Video.ItemsBean) getItem(position);
    ImageView img = (ImageView) listView.findViewById(R.id.photo);
    TextView title = (TextView) listView.findViewById(R.id.videotitle);
    TextView author = (TextView) listView.findViewById(R.id.author);
    TextView desc = (TextView) listView.findViewById(R.id.description);

    title.setText(i.getSnippet().getTitle());
    author.setText(i.getSnippet().getChannelId());
    desc.setText(i.getSnippet().getDescription());
    String imghttp = i.getSnippet().getThumbnails().getMedium().getUrl();
    Picasso.with(ct).load(imghttp).into(img);

    return listView;

}
}

/*
@Override
    public View getView(int position, View v, ViewGroup root){
        LayoutInflater inflater = (LayoutInflater) ct
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View listView = inflater.inflate(R.layout.list, root, false);


    }
 Video.ItemsBean i = (Video.ItemsBean) getItem(position);
        ImageView img = (ImageView) listView.findViewById(R.id.photo);
        TextView title = (TextView) listView.findViewById(R.id.videotitle);
        TextView author = (TextView) listView.findViewById(R.id.author);
        TextView desc = (TextView) listView.findViewById(R.id.description);

        title.setText(i.getSnippet().getTitle());
        author.setText(i.getSnippet().getChannelId());
        desc.setText(i.getSnippet().getDescription());
        String imghttp = i.getSnippet().getThumbnails().getMedium().getUrl();
        Picasso.with(ct).load(imghttp).into(img);

        return listView;
 */