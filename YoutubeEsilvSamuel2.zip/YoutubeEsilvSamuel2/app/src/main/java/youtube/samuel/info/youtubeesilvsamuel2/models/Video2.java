package youtube.samuel.info.youtubeesilvsamuel2.models;

import java.util.List;

/**
 * Created by sam88 on 23/03/2017.
 */

public class Video2 {

    private List<ItemsBean> items;

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    public static class ItemsBean {
        /**
         * id : 1wYNFfgrXTI
         * snippet : {"channelId":"UC20vb-R_px4CguHzzBPhoyQ","title":"Eminem - When I'm Gone","description":"Music video by Eminem performing When I'm Gone. (C) 2005 Aftermath Entertainment/Interscope Records","categoryId":"10"}
         * statistics : {"viewCount":"501814682","likeCount":"2435359","dislikeCount":"63959","favoriteCount":"0","commentCount":"223053"}
         */

        private String id;
        private SnippetBean snippet;
        private StatisticsBean statistics;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public SnippetBean getSnippet() {
            return snippet;
        }

        public void setSnippet(SnippetBean snippet) {
            this.snippet = snippet;
        }

        public StatisticsBean getStatistics() {
            return statistics;
        }

        public void setStatistics(StatisticsBean statistics) {
            this.statistics = statistics;
        }

        public static class SnippetBean {
            /**
             * channelId : UC20vb-R_px4CguHzzBPhoyQ
             * title : Eminem - When I'm Gone
             * description : Music video by Eminem performing When I'm Gone. (C) 2005 Aftermath Entertainment/Interscope Records
             * categoryId : 10
             */

            private String channelId;
            private String title;
            private String description;
            private String categoryId;

            public String getChannelId() {
                return channelId;
            }

            public void setChannelId(String channelId) {
                this.channelId = channelId;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public String getCategoryId() {
                return categoryId;
            }

            public void setCategoryId(String categoryId) {
                this.categoryId = categoryId;
            }
        }

        public static class StatisticsBean {
            /**
             * viewCount : 501814682
             * likeCount : 2435359
             * dislikeCount : 63959
             * favoriteCount : 0
             * commentCount : 223053
             */

            private String viewCount;
            private String likeCount;
            private String dislikeCount;
            private String favoriteCount;
            private String commentCount;

            public String getViewCount() {
                return viewCount;
            }

            public void setViewCount(String viewCount) {
                this.viewCount = viewCount;
            }

            public String getLikeCount() {
                return likeCount;
            }

            public void setLikeCount(String likeCount) {
                this.likeCount = likeCount;
            }

            public String getDislikeCount() {
                return dislikeCount;
            }

            public void setDislikeCount(String dislikeCount) {
                this.dislikeCount = dislikeCount;
            }

            public String getFavoriteCount() {
                return favoriteCount;
            }

            public void setFavoriteCount(String favoriteCount) {
                this.favoriteCount = favoriteCount;
            }

            public String getCommentCount() {
                return commentCount;
            }

            public void setCommentCount(String commentCount) {
                this.commentCount = commentCount;
            }
        }
    }
}
