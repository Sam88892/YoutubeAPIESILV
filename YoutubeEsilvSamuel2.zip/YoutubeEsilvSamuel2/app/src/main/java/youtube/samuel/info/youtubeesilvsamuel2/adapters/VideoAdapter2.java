package youtube.samuel.info.youtubeesilvsamuel2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import youtube.samuel.info.youtubeesilvsamuel2.R;
import youtube.samuel.info.youtubeesilvsamuel2.models.Video;
import youtube.samuel.info.youtubeesilvsamuel2.models.Video2;

/**
 * Created by sam88 on 22/03/2017.
 */

public class VideoAdapter2 extends BaseAdapter {

    private List<Video2.ItemsBean> details;
    private Context ct2;
    Video2.ItemsBean item2;


    public VideoAdapter2(Context ct2, List<Video2.ItemsBean> details)
    {
        this.ct2 = ct2;
        this.details =details;
    }



    @Override
    public int getCount() {
        return details.size();
    }

    @Override
    public Object getItem(int position) {
        {
            return details.get(position);
        }
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View v2, ViewGroup root2) {


    LayoutInflater inflater2 = (LayoutInflater) ct2
            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View listView2 = inflater2.inflate(R.layout.list, root2, false);



    TextView desc2= (TextView) listView2.findViewById(R.id.description2);



        desc2.setText(item2.getSnippet().getDescription());

    return listView2;

}
}
