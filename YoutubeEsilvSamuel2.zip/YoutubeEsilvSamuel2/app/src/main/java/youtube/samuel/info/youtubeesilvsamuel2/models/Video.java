package youtube.samuel.info.youtubeesilvsamuel2.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by sam88 on 21/03/2017.
 */

public class Video {


    /**
     * kind : youtube#searchListResponse
     * etag : "uQc-MPTsstrHkQcRXL3IWLmeNsM/88_A1qmKJRarnYdLPQUl6luTe4Y"
     * nextPageToken : CDIQAA
     * regionCode : FR
     * pageInfo : {"totalResults":1000000,"resultsPerPage":50}
     * items : [{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/C8mHanpF07cVFsBlpycYlHIqrVk\"","id":{"kind":"youtube#video","videoId":"gX9lrUdYh7Q"},"snippet":{"publishedAt":"2017-03-21T14:11:55.000Z","channelId":"UCC9ZIpLRneyc3gyoCrEj1uw","title":"Wyprawa po Upgrade - test GeForce GTX 1080Ti","description":"To nie jest materiał sponsorowany, ale sprzęt do testów dostałem od NVIDIA Polska. Fejsy me: http://www.facebook.com/quazTV Mój mały unboxing oraz test ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/hqdefault.jpg","width":480,"height":360}},"channelTitle":"quaz9","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/ZWWpct7CLelELWlfIvRZj5eDtoI\"","id":{"kind":"youtube#video","videoId":"q5l9Vq2CKdg"},"snippet":{"publishedAt":"2017-03-18T18:53:03.000Z","channelId":"UCe_vXdMrHHseZ_esYUskSBw","title":"8 Kitchen Gadgets Put to the Test","description":"1 BambooBread Slicer - http://amzn.to/2nlAusS 2 Hot Dog Dicer - http://amzn.to/2nDvCwk 3 Strawberry Huller - http://amzn.to/2nDr1du 4 Grape and Tomato ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/q5l9Vq2CKdg/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/q5l9Vq2CKdg/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/q5l9Vq2CKdg/hqdefault.jpg","width":480,"height":360}},"channelTitle":"CrazyRussianHacker","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/MLG98kGQZs_8JKC5jjIsNfVYzD8\"","id":{"kind":"youtube#video","videoId":"IC4ANBT22wY"},"snippet":{"publishedAt":"2017-03-20T16:30:01.000Z","channelId":"UCTafEJoRl5myC8A50plIrng","title":"Qui arrivera à passer ce test d'attention ?","description":"Déroulez la description il y a de bonnes infos *** Les 4 #ImpossibleChallenge : https://goo.gl/mDNvm1 Vidéo de l'attention sélective de BrainDayProject ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/IC4ANBT22wY/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/IC4ANBT22wY/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/IC4ANBT22wY/hqdefault.jpg","width":480,"height":360}},"channelTitle":"FabienOlicard","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/M8ivwMEmoTWkQIj3CLKkP5IzRqU\"","id":{"kind":"youtube#video","videoId":"xHIykZgE7HY"},"snippet":{"publishedAt":"2016-08-01T11:36:33.000Z","channelId":"UC3z81y3dM8Z1x1fGmUtHrFw","title":"Color Blind Test - Can You Actually See All The Colors?","description":"Are you color blind? How sharp is your vision? This color blind test will check your eyes to see if you can actually see all the colors. While color blindness is ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/xHIykZgE7HY/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/xHIykZgE7HY/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/xHIykZgE7HY/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Mind Oddities","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/T5MkJ_v9DrK7b4QV4U3cr4Pr08w\"","id":{"kind":"youtube#video","videoId":"ZWJm72Jr4f0"},"snippet":{"publishedAt":"2017-03-17T20:45:11.000Z","channelId":"UCDlQwv99CovKafGvxyaiNDA","title":"The Ultimate LG G6 Water Survival Test!","description":"Can the LG G6 Survive a Waterfall? a Pressure Washer? Enjoy! The $1500 Smart Room :o ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/ZWJm72Jr4f0/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/ZWJm72Jr4f0/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/ZWJm72Jr4f0/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Jonathan Morrison","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/ebRLRk6KDFlpDIWTLoHoEeJLV_E\"","id":{"kind":"youtube#video","videoId":"pNTwRSKVJLc"},"snippet":{"publishedAt":"2017-02-24T18:00:05.000Z","channelId":"UCpko_-a4wgz2u_DgDgd9fqA","title":"Can You Pass One Of The Hardest South Korean Tests?","description":"Imagine taking this test in your second language. Check out more awesome videos at BuzzFeedVideo! http://bit.ly/YTbuzzfeedvideo GET MORE BUZZFEED: ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/pNTwRSKVJLc/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/pNTwRSKVJLc/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/pNTwRSKVJLc/hqdefault.jpg","width":480,"height":360}},"channelTitle":"BuzzFeedVideo","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/nRAP-OBSglpL3wWdoP9mWoP22Zw\"","id":{"kind":"youtube#video","videoId":"oNmLUEE-YAk"},"snippet":{"publishedAt":"2017-03-18T15:00:09.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"HTC Ultra Durability Test - Scratch, burn, BEND test!","description":"Back again with another smartphone durabilty test. How bow dah? This time we are checking the durability of the Newest flagship from HTC the HTC U Ultra.","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/oNmLUEE-YAk/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/oNmLUEE-YAk/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/oNmLUEE-YAk/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/tdakKlLfA0fnOWGiQeTLwdHM31k\"","id":{"kind":"youtube#video","videoId":"gHBZquXRnQg"},"snippet":{"publishedAt":"2016-11-23T21:57:59.000Z","channelId":"UChM5Ff2yVeIZ16EWiB081cg","title":"Funniest Test Answers From Kids!","description":"In this Reaction Time Episode I reacted to the smartest answers kids gave on their tests and quizzes that totally confused their teachers. For Video Submissions ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/gHBZquXRnQg/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/gHBZquXRnQg/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/gHBZquXRnQg/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Reaction Time","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/c9YvMdvO1JjHJVmoidIfhVPr1Dw\"","id":{"kind":"youtube#video","videoId":"FhZrU6g9seg"},"snippet":{"publishedAt":"2016-06-23T16:00:00.000Z","channelId":"UCC552Sd-3nyi_tk2BudLUzA","title":"Will This Trick Your Brain? (Color TEST)","description":"Your eyes and brain are pretty amazing! Watch ART vs SCIENCE: https://youtu.be/6Z37JA-wmgQ Subscribe: http://bit.ly/asapsci Written by Rachel Salt, Gregory ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/FhZrU6g9seg/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/FhZrU6g9seg/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/FhZrU6g9seg/hqdefault.jpg","width":480,"height":360}},"channelTitle":"AsapSCIENCE","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/6lDgvCY2jRkCvtmaIdQmydSMTjA\"","id":{"kind":"youtube#video","videoId":"VxcbppCX6Rk"},"snippet":{"publishedAt":"2013-08-13T14:00:19.000Z","channelId":"UCC552Sd-3nyi_tk2BudLUzA","title":"How Old Are Your Ears? (Hearing Test)","description":"MUST WATCH IN 1080p AND USE HEADPHONES* How high can you hear? Take this 'test' to see how old your ears are! SUBSCRIBE (it's free!)","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/VxcbppCX6Rk/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/VxcbppCX6Rk/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/VxcbppCX6Rk/hqdefault.jpg","width":480,"height":360}},"channelTitle":"AsapSCIENCE","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/S2MgA-j3T6XzkqyUp5zMPusrndE\"","id":{"kind":"youtube#video","videoId":"x2KucWHrvCE"},"snippet":{"publishedAt":"2016-04-19T00:00:00.000Z","channelId":"UCgJjd8J5moTQSwnCIx4WSIw","title":"34 Dumbest Answers Kids Ever Gave On Tests","description":"From talking about bacon, to answers that take inappropriateness to a whole new level, we count 34 hilariously wrong answers that kids wrote on tests ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/x2KucWHrvCE/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/x2KucWHrvCE/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/x2KucWHrvCE/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Planet Dolan","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/uQTQltN87NLJQC9AajUBtpr6NwE\"","id":{"kind":"youtube#video","videoId":"r-NAJiX5OW0"},"snippet":{"publishedAt":"2017-03-18T16:00:07.000Z","channelId":"UCBzfdgfIAANfgP3xyhVaEfQ","title":"A Day w/ the New Alfa Romeo Stelvio - Road Test & Review","description":"Subscribe! http://bit.ly/SubscribeToMarchettino - My latest adventure takes me behind the wheel of the brand new Alfa Romeo Stelvio Q4 for a test drive and ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/r-NAJiX5OW0/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/r-NAJiX5OW0/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/r-NAJiX5OW0/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Marchettino","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/TNd3GfuBwwleNKgAuBkToyecn0Q\"","id":{"kind":"youtube#video","videoId":"DGANG25Ji1c"},"snippet":{"publishedAt":"2017-03-16T00:06:25.000Z","channelId":"UCke6I9N4KfC968-yRcd5YRg","title":"FUNNY TEST ANSWERS FROM KIDS!!","description":"SSundee checks out some test answers...lol! Don't Forget to subscribe if you are new! Also, show some love with a like if you enjoyed! Watch more reaction ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/DGANG25Ji1c/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/DGANG25Ji1c/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/DGANG25Ji1c/hqdefault.jpg","width":480,"height":360}},"channelTitle":"SSundee","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/rjR0WwOnPZZndhGZqMWBV70Iy4I\"","id":{"kind":"youtube#video","videoId":"_5aXkW0EFRI"},"snippet":{"publishedAt":"2017-03-14T15:00:07.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Nokia 6 Durability Test - Scratch, Burn, And BEND tested","description":"Its time to put Nokias latest creation up against the JerryRigEverything standard durability tests. Will the Nokia name honor the incredible battle tested invincible ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/_5aXkW0EFRI/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/_5aXkW0EFRI/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/_5aXkW0EFRI/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/S15vBpXquHQHbNkosuyXmdtBeI4\"","id":{"kind":"youtube#video","videoId":"tB5-JahAXfc"},"snippet":{"publishedAt":"2015-04-02T14:14:10.000Z","channelId":"UCC552Sd-3nyi_tk2BudLUzA","title":"How Good Is Your Eyesight? (TEST)","description":"Who do you see? More AMAZING illusions: http://bit.ly/asapillusion SUBSCRIBE! (it's free) http://bit.ly/10kWnZ7 GET THE BOOK: http://asapscience.com/book/ ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/tB5-JahAXfc/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/tB5-JahAXfc/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/tB5-JahAXfc/hqdefault.jpg","width":480,"height":360}},"channelTitle":"AsapSCIENCE","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/N2BPHEQHoosR1zH2u9JMggeJqH4\"","id":{"kind":"youtube#video","videoId":"0vYfAqEyGV0"},"snippet":{"publishedAt":"2016-09-16T00:20:00.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"iPhone 7 Scratch test - BEND TEST - Durability video!","description":"Can the iPhone 7 survive the JerryRigEverything Durability tests? Like always we'll start with the scratch test from Mohs scale of hardness. With this test we can ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/0vYfAqEyGV0/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/0vYfAqEyGV0/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/0vYfAqEyGV0/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/3JBXs6eeJhR0gCsww-LoFeyGXSQ\"","id":{"kind":"youtube#video","videoId":"0pAz6LTdTrw"},"snippet":{"publishedAt":"2017-03-05T15:00:23.000Z","channelId":"UCpko_-a4wgz2u_DgDgd9fqA","title":"The Try Guys Take A Friendship DNA Test","description":"Which of The Try Guys are the most, and the least, compatible? Check out more awesome videos at BuzzFeedVideo! http://bit.ly/YTbuzzfeedvideo GET MORE ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/0pAz6LTdTrw/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/0pAz6LTdTrw/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/0pAz6LTdTrw/hqdefault.jpg","width":480,"height":360}},"channelTitle":"BuzzFeedVideo","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/UnqH6H7vnjn36iskMthHbzU74Sc\"","id":{"kind":"youtube#video","videoId":"DB2_HgP7Hjw"},"snippet":{"publishedAt":"2016-12-01T18:00:05.000Z","channelId":"UCi9cDo6239RAzPpBZO9y5SA","title":"CHEATING ON A TEST | Lele Pons","description":"Watch this funny video on how Lele Pons and her classmates work together to cheat on a test. SUBSCRIBE HERE ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/DB2_HgP7Hjw/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/DB2_HgP7Hjw/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/DB2_HgP7Hjw/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Lele Pons","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/nWw8cDY1ZXVh2h9jeAZkqCMS7Hk\"","id":{"kind":"youtube#video","videoId":"ypAc7DhzAA0"},"snippet":{"publishedAt":"2016-03-28T19:00:03.000Z","channelId":"UCpko_-a4wgz2u_DgDgd9fqA","title":"Adults Try To Pass A Fourth Grade Test","description":"College is way easier than the fourth grade.\u201d Check out more awesome videos at BuzzFeedVideo! http://bit.ly/YTbuzzfeedvideo MUSIC Toss It Up Licensed via ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/ypAc7DhzAA0/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/ypAc7DhzAA0/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/ypAc7DhzAA0/hqdefault.jpg","width":480,"height":360}},"channelTitle":"BuzzFeedVideo","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/QHaRXuLfVhnHZ0sztPwvm-yBOPU\"","id":{"kind":"youtube#video","videoId":"Di83JpaRG-I"},"snippet":{"publishedAt":"2017-03-20T12:00:01.000Z","channelId":"UCenIlYGaRI-C3Xa2zgkeLig","title":"Trail Tech Vapor SECOND CHANCE - No BS Test","description":"Back in 2008, this thing was GARBAGE. Is it still garbage? That's what I set out to test in this video. This is the Trail Tech Vapor computer kit for the CRF230F, ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/Di83JpaRG-I/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/Di83JpaRG-I/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/Di83JpaRG-I/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Frickin Jim's Frickin Adventures","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/OME4yGOVK9ebxPpbIOLMcSUENJw\"","id":{"kind":"youtube#video","videoId":"KfKhESzB6Ec"},"snippet":{"publishedAt":"2017-03-20T21:00:03.000Z","channelId":"UCJcmcStuyZVEkQheqINZjBA","title":"Test How Connected Are You To The Universe","description":"Event Is Coming Soon - Test How Connected Are You To The Universe Look up at the stars and not down at your feet. Try to make sense of what you see, and ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/KfKhESzB6Ec/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/KfKhESzB6Ec/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/KfKhESzB6Ec/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Event Is Coming Soon","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/yz0-Wvs7TXNw1BsZH-fM_isppXM\"","id":{"kind":"youtube#video","videoId":"qBSGmAoDcT0"},"snippet":{"publishedAt":"2016-07-11T13:00:02.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Xiaomi Redmi 3 Pro - Bend test, Scratch test, Burn test - Durability video","description":"How durable is the Redmi 3 Pro? Lets find out, with the standard JerryRigEverything scratch test, burn test, and bend test. The Xiaomi 'redmi' lineup of phones is ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/qBSGmAoDcT0/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/qBSGmAoDcT0/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/qBSGmAoDcT0/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/lI-eR3HKR5BHtuYx412ufHjZ9m4\"","id":{"kind":"youtube#video","videoId":"7YtD86bio5U"},"snippet":{"publishedAt":"2014-04-23T13:03:31.000Z","channelId":"UCoUXxtd712vGe5p5lBk_eMg","title":"The Sleep Test","description":"Sleep tips: http://goo.gl/UtJQpm Buy relaxing music on iTunes: https://itunes.apple.com/album/night-school-sleep-music/id863489364 Buy Night School (UK): ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/7YtD86bio5U/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/7YtD86bio5U/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/7YtD86bio5U/hqdefault.jpg","width":480,"height":360}},"channelTitle":"In59seconds","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/020Lot7qoHESLMn0OY-O1yfLiDQ\"","id":{"kind":"youtube#video","videoId":"QZA7ZqYnnfA"},"snippet":{"publishedAt":"2017-03-21T15:28:15.000Z","channelId":"UCeGI6SsTv_M1V3Aeymgm6mg","title":"ISRO commissions World\u2019s 3rd-largest Wind Tunnel for space vehicle test","description":"The Indian Space Research Organisation (ISRO) created history on Monday by commissioning the world's third-largest hypersonic wind tunnel at the Vikram ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/QZA7ZqYnnfA/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/QZA7ZqYnnfA/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/QZA7ZqYnnfA/hqdefault.jpg","width":480,"height":360}},"channelTitle":"all in one","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/gdaegvhynPmgnHEQC0YLJIt8ThU\"","id":{"kind":"youtube#video","videoId":"ElJZM4QHjDQ"},"snippet":{"publishedAt":"2017-03-20T00:04:33.000Z","channelId":"UCzznO4xSV8BKnUBPyswtCUw","title":"North Korea says it conducted high-thrust engine test","description":"북한, 미국 본토 타격 ICBM 엔진 완성단계...발사 임박한 듯 But there seems to be no end to North Korea's military ambitions... as the regime let its presence be ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/ElJZM4QHjDQ/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/ElJZM4QHjDQ/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/ElJZM4QHjDQ/hqdefault.jpg","width":480,"height":360}},"channelTitle":"ARIRANG NEWS","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/XG3QhDobkvuHZYITPGmr_t5feZE\"","id":{"kind":"youtube#video","videoId":"sVzdh_MGQ1g"},"snippet":{"publishedAt":"2017-02-01T18:30:03.000Z","channelId":"UC-BRUJOtblqGrftY6oRcOZw","title":"TEST NAJOSTRZEJSZY CHIPS za 300 ZŁ!","description":"DUŻO ŁAPEK I TESTUJEMY KOLEJNE OSTRE RZECZY! D: W dzisiejszym filmie, który nagrałem dość dawno zrobimy sławne aktualnie na youtube TESTY ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/sVzdh_MGQ1g/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/sVzdh_MGQ1g/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/sVzdh_MGQ1g/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Blowek","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/x2efFyLz7ecQVrBgel2VhON97Yo\"","id":{"kind":"youtube#video","videoId":"ZK20HZrTleY"},"snippet":{"publishedAt":"2016-10-08T10:02:30.000Z","channelId":"UCoU9AdLQr9ZT7xDBXnhB6Fw","title":"IPHONE 7 - EKSTREMALNY TEST, RECENZJA #110","description":"Słyszałeś ten fajny nowy dźwięk po dawaniu łapki w górę? B) https://youtu.be/B_LvXH2op8M ◅Profesjonalny test u Mandzia ▽ ▽ ▽ W RAZIE POŻARU ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/ZK20HZrTleY/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/ZK20HZrTleY/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/ZK20HZrTleY/hqdefault.jpg","width":480,"height":360}},"channelTitle":"THEUNBOXALL","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/Xy4iNxh16TSgP7nWrI7Us01YD7w\"","id":{"kind":"youtube#video","videoId":"rbluz8iXUm8"},"snippet":{"publishedAt":"2016-12-25T16:00:04.000Z","channelId":"UCW7ynWRM5oKdxHwmCxwxllw","title":"KENDİNİ NE KADAR TANIYORSUN? VİDEO TEST","description":"KANALIMA ÜCRETSİZ ABONE OLUN = http://goo.gl/yCRwMs Yeni Video Yayında = TATİL İÇİN TEHLİKELİ 5 TURİSTİK YER ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/rbluz8iXUm8/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/rbluz8iXUm8/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/rbluz8iXUm8/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Duymayan KALMASIN!","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/0BKDugrNNSgk9v-ZMN8VeJ0dThw\"","id":{"kind":"youtube#video","videoId":"CBcUEKs4ykw"},"snippet":{"publishedAt":"2017-03-19T09:42:38.000Z","channelId":"UCzznO4xSV8BKnUBPyswtCUw","title":"North Korea says it conducted high-thrust engine test","description":"북한, 미국 본토 타격 ICBM 엔진 완성단계...발사 임박한 듯 While talks of North Korea's nuclear issues dominted talks during Tillerson's East Asia tour... the regime ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/CBcUEKs4ykw/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/CBcUEKs4ykw/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/CBcUEKs4ykw/hqdefault.jpg","width":480,"height":360}},"channelTitle":"ARIRANG NEWS","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/euWnl4E8wU41k2B6VPmejoAMEog\"","id":{"kind":"youtube#video","videoId":"cgY8w7DZhLU"},"snippet":{"publishedAt":"2016-12-30T20:00:04.000Z","channelId":"UChM5Ff2yVeIZ16EWiB081cg","title":"Am I Gay Or Straight? (Taking The Gay Test)","description":"In this Reaction Time Episode I took the \"Are You Gay Test\" which consisted of a bunch of random questions that guess whether you're straight or not. This quiz ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/cgY8w7DZhLU/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/cgY8w7DZhLU/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/cgY8w7DZhLU/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Reaction Time","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/jhTHbIrTn5SJcqyRaBq99kwCFtg\"","id":{"kind":"youtube#video","videoId":"hD9Ig6iD1Oo"},"snippet":{"publishedAt":"2016-11-14T14:02:04.000Z","channelId":"UCW7ynWRM5oKdxHwmCxwxllw","title":"FARKINIZI İSPAT ETMEK İÇİN 5 TEST","description":"KANALIMA ÜCRETSİZ ABONE OLUN = http://goo.gl/yCRwMs Yeni Video Yayında = TUHAF İSTEKLERLE AMELİYAT OLAN 10 İNSAN ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/hD9Ig6iD1Oo/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/hD9Ig6iD1Oo/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/hD9Ig6iD1Oo/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Duymayan KALMASIN!","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/pvoGwDNY5aYbN9NQM_zoi5WkbL4\"","id":{"kind":"youtube#video","videoId":"d2jav7UdQtE"},"snippet":{"publishedAt":"2016-04-21T02:00:50.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Xiaomi Mi5 Bend Test - Scratch test - Burn test - Durability test","description":"Xiaomi is one of the biggest smart phone manufacturers in the world! But... do they design a solid phone? They are well known for their high end components, ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/d2jav7UdQtE/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/d2jav7UdQtE/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/d2jav7UdQtE/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/gKZcMlIaMUaM7zHbR6SuAm7OIoQ\"","id":{"kind":"youtube#video","videoId":"wjlIhCPAY0w"},"snippet":{"publishedAt":"2015-04-27T23:37:28.000Z","channelId":"UCpko_-a4wgz2u_DgDgd9fqA","title":"Adults Take A 3rd Grade Math Test","description":"I forgot how to write numbers.\u201d Check out more awesome videos at BuzzFeedVideo! http://bit.ly/YTbuzzfeedvideo MUSIC Trinitron Licensed via Warner Chappell ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/wjlIhCPAY0w/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/wjlIhCPAY0w/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/wjlIhCPAY0w/hqdefault.jpg","width":480,"height":360}},"channelTitle":"BuzzFeedVideo","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/EYazgKGZzBACWmL1rmZzdxfWlPA\"","id":{"kind":"youtube#video","videoId":"2j1AivjSlIA"},"snippet":{"publishedAt":"2017-02-16T14:00:00.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Mate 9 Durability Test - Bend Test, Scratch and BURN test","description":"Get your Mate 9 HERE: http://amzn.to/2lUHFnx Will the Mate 9 stand up the daily abuse of every day life? Is the screen made of quality glass? Does it have real ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/2j1AivjSlIA/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/2j1AivjSlIA/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/2j1AivjSlIA/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/PKZ2x-LznaHon9lSd7XEJvrsyCQ\"","id":{"kind":"youtube#video","videoId":"4MJA8Wzp2XM"},"snippet":{"publishedAt":"2015-10-26T19:11:27.000Z","channelId":"UCOmrniWfKi-uCD6Oh6fqhgw","title":"Coombs Test Made Simple","description":"LIKE US ON FACEBOOK : fb.me/Medsimplified BUY USING AFFILIATE LINKS : AMAZON US--- https://goo.gl/XSJtTx AMAZON India http://goo.gl/QsUhku ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/4MJA8Wzp2XM/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/4MJA8Wzp2XM/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/4MJA8Wzp2XM/hqdefault.jpg","width":480,"height":360}},"channelTitle":"MEDSimplified","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/q8nXcmGnA_6A3ARRImLHF-v5yxI\"","id":{"kind":"youtube#video","videoId":"VqCCgLvRbBU"},"snippet":{"publishedAt":"2017-03-17T18:42:40.000Z","channelId":"UCC9ZIpLRneyc3gyoCrEj1uw","title":"Nintendo Switch - test quaza","description":"Niektóre gry i sprzęt do testów dostałem od dystrybutora Nintendo - firmy Conquest. Fejsy me: http://www.facebook.com/quazTV Oto mój unboxing oraz test ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/VqCCgLvRbBU/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/VqCCgLvRbBU/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/VqCCgLvRbBU/hqdefault.jpg","width":480,"height":360}},"channelTitle":"quaz9","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/oqggWhTJj9Gu8b_G3-IhHVBf36Q\"","id":{"kind":"youtube#video","videoId":"gZAZy0bn5hc"},"snippet":{"publishedAt":"2017-03-20T04:41:02.000Z","channelId":"UC41xJSNY2xCPC4-gOsRcDcg","title":"MVD Emission Test","description":"The MVD is getting rid of its new emissions notification system, Subscribe to KOAT on YouTube now for more: http://bit.ly/1jocB9r Get more Albuquerque news: ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/gZAZy0bn5hc/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/gZAZy0bn5hc/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/gZAZy0bn5hc/hqdefault.jpg","width":480,"height":360}},"channelTitle":"KOAT","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/YW8_E-cgzoUbxTE5NMvWCgD6BEI\"","id":{"kind":"youtube#video","videoId":"LdAD9GNv8FI"},"snippet":{"publishedAt":"2016-02-08T14:00:00.000Z","channelId":"UC_VQDInMfY5HoPn8w9OmuFw","title":"Straight Leg Raise or Lasègue's Test for Lumbar Radiculopathy","description":"Straight Leg Raise or Lasègue's Test for lumbar radiculopathy. This neurodynamic test is most commonly used in order to assess lumbar radiculopathy or ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/LdAD9GNv8FI/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/LdAD9GNv8FI/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/LdAD9GNv8FI/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Physiotutors","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/8d7XL90Itpk_qaNTtvzfDtwKTFE\"","id":{"kind":"youtube#video","videoId":"ikNtinmJ7M8"},"snippet":{"publishedAt":"2014-06-17T19:52:11.000Z","channelId":"UCqdgeIot-FbCtOpTfGSEftA","title":"Johnny Test - Jonny Test: Party Monster // Johnny Test: Extreme Crime Stopper","description":"Watch the latest Johnny Test episodes, description below! ▻ Subscribe to Johnny Test: http://bit.ly/1Pz97RA After much begging and pleading, the girls finally ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/ikNtinmJ7M8/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/ikNtinmJ7M8/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/ikNtinmJ7M8/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Johnny Test","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/dYA2r9v9yY8Jy3GtXomN9tMeJ5g\"","id":{"kind":"youtube#video","videoId":"9g3cnEacrEo"},"snippet":{"publishedAt":"2016-06-15T17:00:01.000Z","channelId":"UCaBf1a-dpIsw8OxqH4ki2Kg","title":"Test of Pride | Critical Role RPG Show Episode 51","description":"Scanlan tries to plan a safe escape for his daughter Kaylie, while Grog makes his way to the center of Westrunn for his final confrontation with his uncle Kevdak.","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/9g3cnEacrEo/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/9g3cnEacrEo/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/9g3cnEacrEo/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Geek & Sundry","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/M792laH2sCGzYtxgU1xN7WWVPVo\"","id":{"kind":"youtube#video","videoId":"k7H9OmV0OPI"},"snippet":{"publishedAt":"2016-08-16T09:27:14.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Redmi Note 3 - Durability Video - Scratch, Burn, Bend Test","description":"Ever wonder how durable your new Redmi Note 3 is? Is it possible to bend with your hands? Will it bend in your pocket? or scratch in your purse? How long will ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/k7H9OmV0OPI/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/k7H9OmV0OPI/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/k7H9OmV0OPI/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/DOsASs2ol-VcOgdOry32ivGQG4s\"","id":{"kind":"youtube#video","videoId":"SdQRkmdhwJs"},"snippet":{"publishedAt":"2015-09-16T16:22:22.000Z","channelId":"UCpB-1KQc7U11jl-7YzedxFQ","title":"Hazard perception test 2017: official DVSA guide","description":"Hazard perception part of the theory test explained http://www.gov.uk/theorytest - when to click, how to get high scores, and how to pass. Watch how the whole of ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/SdQRkmdhwJs/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/SdQRkmdhwJs/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/SdQRkmdhwJs/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Driver and Vehicle Standards Agency","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/IoTTMg8HN29W8N2EiWoMaHGD4aA\"","id":{"kind":"youtube#video","videoId":"PFp2-lVZUqE"},"snippet":{"publishedAt":"2017-03-19T13:36:05.000Z","channelId":"UCzznO4xSV8BKnUBPyswtCUw","title":"North Korea says it conducted high-thrust engine test","description":"북한, 미국 본토 타격 ICBM 엔진 완성단계...발사 임박한 듯 While talks of North Korea's nuclear issues dominted talks during Tillerson's East Asia tour... the regime ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/PFp2-lVZUqE/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/PFp2-lVZUqE/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/PFp2-lVZUqE/hqdefault.jpg","width":480,"height":360}},"channelTitle":"ARIRANG NEWS","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/zlzyCZiDcdyiCBqGyxFNCTiDVC4\"","id":{"kind":"youtube#video","videoId":"0tXxFPHzFFI"},"snippet":{"publishedAt":"2014-08-21T16:43:38.000Z","channelId":"UC4a-Gbdw7vOaccHmFo40b9g","title":"Comparison test","description":"Comparison test for series convergence or divergence More free lessons at: http://www.khanacademy.org/video?v=0tXxFPHzFFI.","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/0tXxFPHzFFI/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/0tXxFPHzFFI/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/0tXxFPHzFFI/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Khan Academy","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/sNZlYEWGRjOZ10hsZh-emar7Gmg\"","id":{"kind":"youtube#video","videoId":"YdtBnjX_PXM"},"snippet":{"publishedAt":"2015-11-18T02:58:02.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"BlackBerry Priv - Scratch Test, Burn Test, Bend Test","description":"This video shows the durability of the Blackberry Priv, The Newest Android Smart phone from Blackberry: http://amzn.to/2hyAPWC A good smart phone repair ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/YdtBnjX_PXM/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/YdtBnjX_PXM/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/YdtBnjX_PXM/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/aPYJ5-AoRMF2ZEXM3ZChDvPy2sw\"","id":{"kind":"youtube#video","videoId":"kZOfYo4JDIw"},"snippet":{"publishedAt":"2016-07-31T04:29:05.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Worlds THINNEST Smartphone BEND TEST - Moto Z","description":"How durable is the worlds thinnest smartphone? Lets find out. This phone is only 5.2 millimeters thick! Can it hold up to being scratched on every single surface?","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/kZOfYo4JDIw/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/kZOfYo4JDIw/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/kZOfYo4JDIw/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/wVLFQYX5PyAnyOnV8VOKJ7rLMDQ\"","id":{"kind":"youtube#video","videoId":"LFJI0tLMVpI"},"snippet":{"publishedAt":"2008-11-14T16:19:53.000Z","channelId":"UCVxeemxu4mnxfVnBKNFl6Yg","title":"Extreme Traction-Control Test","description":"As part of the 2008 PickupTrucks.com Half-Ton Shootout, PickupTrucks.com put six half-ton pickups from Chevrolet, Dodge, Ford, GMC, Nissan and Toyota ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/LFJI0tLMVpI/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/LFJI0tLMVpI/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/LFJI0tLMVpI/hqdefault.jpg","width":480,"height":360}},"channelTitle":"Cars.com","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/ni8BjohwiBPoUOmu_-Y9g10uSRQ\"","id":{"kind":"youtube#video","videoId":"CVIIsyD2H5s"},"snippet":{"publishedAt":"2015-09-25T01:51:37.000Z","channelId":"UChYU73igK5wQhWAXPh3X8PA","title":"iPhone 6S and 6S Plus Drop Test!","description":"Get your free month of protection now: http://info.icracked.com/advantage-welcomes-phone-buff Drop test of the new Apple iPhone 6S and 6S Plus. These new ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/CVIIsyD2H5s/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/CVIIsyD2H5s/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/CVIIsyD2H5s/hqdefault.jpg","width":480,"height":360}},"channelTitle":"PhoneBuff","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/3MeS8wij3JUvPY-VkX2aCmVXaMo\"","id":{"kind":"youtube#video","videoId":"JIeoHULj_pg"},"snippet":{"publishedAt":"2016-07-01T23:00:36.000Z","channelId":"UCe_vXdMrHHseZ_esYUskSBw","title":"10 Butter Gadgets Put to the TEST","description":"More Gadgets - https://www.youtube.com/watch?v=g8CFUPpsj_8&list=PLat_oTO7cmoz06vkp4-8Qwf5kiSBt8cLJ Subscribe to my 2nd channel ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/JIeoHULj_pg/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/JIeoHULj_pg/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/JIeoHULj_pg/hqdefault.jpg","width":480,"height":360}},"channelTitle":"CrazyRussianHacker","liveBroadcastContent":"none"}},{"kind":"youtube#searchResult","etag":"\"uQc-MPTsstrHkQcRXL3IWLmeNsM/ZNfrSByxNqSY8bao8yA0OU7sIV8\"","id":{"kind":"youtube#video","videoId":"OJ9-sTXPoek"},"snippet":{"publishedAt":"2016-02-03T23:51:40.000Z","channelId":"UCWFKCr40YwOZQx8FHU_ZqqQ","title":"Huawei honor 5x - Bend Test, Scratch Test, Burn Test","description":"Here is the $199 dollar phone on Amazon: http://amzn.to/1PSTmSA Let me know if that link stops working! Got my hands on one of the brand new Huawai honor ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/OJ9-sTXPoek/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/OJ9-sTXPoek/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/OJ9-sTXPoek/hqdefault.jpg","width":480,"height":360}},"channelTitle":"JerryRigEverything","liveBroadcastContent":"none"}}]
     */

    private String kind;
    private String etag;
    private String nextPageToken;
    private String regionCode;
    private PageInfoBean pageInfo;
    private List<ItemsBean> items;

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getEtag() {
        return etag;
    }

    public void setEtag(String etag) {
        this.etag = etag;
    }

    public String getNextPageToken() {
        return nextPageToken;
    }

    public void setNextPageToken(String nextPageToken) {
        this.nextPageToken = nextPageToken;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public PageInfoBean getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(PageInfoBean pageInfo) {
        this.pageInfo = pageInfo;
    }

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    public class PageInfoBean {
        /**
         * totalResults : 1000000
         * resultsPerPage : 50
         */

        private int totalResults;
        private int resultsPerPage;

        public int getTotalResults() {
            return totalResults;
        }

        public void setTotalResults(int totalResults) {
            this.totalResults = totalResults;
        }

        public int getResultsPerPage() {
            return resultsPerPage;
        }

        public void setResultsPerPage(int resultsPerPage) {
            this.resultsPerPage = resultsPerPage;
        }
    }

    public class ItemsBean {
        /**
         * kind : youtube#searchResult
         * etag : "uQc-MPTsstrHkQcRXL3IWLmeNsM/C8mHanpF07cVFsBlpycYlHIqrVk"
         * id : {"kind":"youtube#video","videoId":"gX9lrUdYh7Q"}
         * snippet : {"publishedAt":"2017-03-21T14:11:55.000Z","channelId":"UCC9ZIpLRneyc3gyoCrEj1uw","title":"Wyprawa po Upgrade - test GeForce GTX 1080Ti","description":"To nie jest materiał sponsorowany, ale sprzęt do testów dostałem od NVIDIA Polska. Fejsy me: http://www.facebook.com/quazTV Mój mały unboxing oraz test ...","thumbnails":{"default":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/hqdefault.jpg","width":480,"height":360}},"channelTitle":"quaz9","liveBroadcastContent":"none"}
         */

        private String kind;
        private String etag;
        private IdBean id;
        private SnippetBean snippet;

        public String getKind() {
            return kind;
        }

        public void setKind(String kind) {
            this.kind = kind;
        }

        public String getEtag() {
            return etag;
        }

        public void setEtag(String etag) {
            this.etag = etag;
        }

        public IdBean getId() {
            return id;
        }

        public void setId(IdBean id) {
            this.id = id;
        }

        public SnippetBean getSnippet() {
            return snippet;
        }

        public void setSnippet(SnippetBean snippet) {
            this.snippet = snippet;
        }

        public class IdBean {
            /**
             * kind : youtube#video
             * videoId : gX9lrUdYh7Q
             */

            private String kind;
            private String videoId;

            public String getKind() {
                return kind;
            }

            public void setKind(String kind) {
                this.kind = kind;
            }

            public String getVideoId() {
                return videoId;
            }

            public void setVideoId(String videoId) {
                this.videoId = videoId;
            }
        }

        public  class SnippetBean {
            /**
             * publishedAt : 2017-03-21T14:11:55.000Z
             * channelId : UCC9ZIpLRneyc3gyoCrEj1uw
             * title : Wyprawa po Upgrade - test GeForce GTX 1080Ti
             * description : To nie jest materiał sponsorowany, ale sprzęt do testów dostałem od NVIDIA Polska. Fejsy me: http://www.facebook.com/quazTV Mój mały unboxing oraz test ...
             * thumbnails : {"default":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/default.jpg","width":120,"height":90},"medium":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/mqdefault.jpg","width":320,"height":180},"high":{"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/hqdefault.jpg","width":480,"height":360}}
             * channelTitle : quaz9
             * liveBroadcastContent : none
             */

            private String publishedAt;
            private String channelId;
            private String title;
            private String description;
            private ThumbnailsBean thumbnails;
            private String channelTitle;
            private String liveBroadcastContent;

            public String getPublishedAt() {
                return publishedAt;
            }

            public void setPublishedAt(String publishedAt) {
                this.publishedAt = publishedAt;
            }

            public String getChannelId() {
                return channelId;
            }

            public void setChannelId(String channelId) {
                this.channelId = channelId;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public ThumbnailsBean getThumbnails() {
                return thumbnails;
            }

            public void setThumbnails(ThumbnailsBean thumbnails) {
                this.thumbnails = thumbnails;
            }

            public String getChannelTitle() {
                return channelTitle;
            }

            public void setChannelTitle(String channelTitle) {
                this.channelTitle = channelTitle;
            }

            public String getLiveBroadcastContent() {
                return liveBroadcastContent;
            }

            public void setLiveBroadcastContent(String liveBroadcastContent) {
                this.liveBroadcastContent = liveBroadcastContent;
            }

            public class ThumbnailsBean {
                /**
                 * default : {"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/default.jpg","width":120,"height":90}
                 * medium : {"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/mqdefault.jpg","width":320,"height":180}
                 * high : {"url":"https://i.ytimg.com/vi/gX9lrUdYh7Q/hqdefault.jpg","width":480,"height":360}
                 */

                @SerializedName("default")
                private DefaultBean defaultX;
                private MediumBean medium;
                private HighBean high;

                public DefaultBean getDefaultX() {
                    return defaultX;
                }

                public void setDefaultX(DefaultBean defaultX) {
                    this.defaultX = defaultX;
                }

                public MediumBean getMedium() {
                    return medium;
                }

                public void setMedium(MediumBean medium) {
                    this.medium = medium;
                }

                public HighBean getHigh() {
                    return high;
                }

                public void setHigh(HighBean high) {
                    this.high = high;
                }

                public  class DefaultBean {
                    /**
                     * url : https://i.ytimg.com/vi/gX9lrUdYh7Q/default.jpg
                     * width : 120
                     * height : 90
                     */

                    private String url;
                    private int width;
                    private int height;

                    public String getUrl() {
                        return url;
                    }

                    public void setUrl(String url) {
                        this.url = url;
                    }

                    public int getWidth() {
                        return width;
                    }

                    public void setWidth(int width) {
                        this.width = width;
                    }

                    public int getHeight() {
                        return height;
                    }

                    public void setHeight(int height) {
                        this.height = height;
                    }
                }

                public  class MediumBean {
                    /**
                     * url : https://i.ytimg.com/vi/gX9lrUdYh7Q/mqdefault.jpg
                     * width : 320
                     * height : 180
                     */

                    private String url;
                    private int width;
                    private int height;

                    public String getUrl() {
                        return url;
                    }

                    public void setUrl(String url) {
                        this.url = url;
                    }

                    public int getWidth() {
                        return width;
                    }

                    public void setWidth(int width) {
                        this.width = width;
                    }

                    public int getHeight() {
                        return height;
                    }

                    public void setHeight(int height) {
                        this.height = height;
                    }
                }

                public class HighBean {
                    /**
                     * url : https://i.ytimg.com/vi/gX9lrUdYh7Q/hqdefault.jpg
                     * width : 480
                     * height : 360
                     */

                    private String url;
                    private int width;
                    private int height;

                    public String getUrl() {
                        return url;
                    }

                    public void setUrl(String url) {
                        this.url = url;
                    }

                    public int getWidth() {
                        return width;
                    }

                    public void setWidth(int width) {
                        this.width = width;
                    }

                    public int getHeight() {
                        return height;
                    }

                    public void setHeight(int height) {
                        this.height = height;
                    }
                }
            }
        }
    }
}
