package youtube.samuel.info.youtubeesilvsamuel2.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.gson.Gson;

import youtube.samuel.info.youtubeesilvsamuel2.Constants;
import youtube.samuel.info.youtubeesilvsamuel2.R;
import youtube.samuel.info.youtubeesilvsamuel2.adapters.VideoAdapter;
import youtube.samuel.info.youtubeesilvsamuel2.adapters.VideoAdapter2;
import youtube.samuel.info.youtubeesilvsamuel2.models.Video;
import youtube.samuel.info.youtubeesilvsamuel2.models.Video2;

import static android.provider.MediaStore.Video.Thumbnails.VIDEO_ID;
import static youtube.samuel.info.youtubeesilvsamuel2.Constants.API_KEY;

/**
 * Created by sam88 on 22/03/2017.
 */



public class videoActivity extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {


    private static final String VIDEO_ID = "YVkUvmDQ3HY";

    public static void start(Context context, String videoId) {

        Intent intent = new Intent(context, videoActivity.class);
        intent.putExtra(VIDEO_ID, videoId);
        context.startActivity(intent);




    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /** attaching layout xml **/
        setContentView(R.layout.activity_video);


        /** Initializing YouTube player view **/
        YouTubePlayerView youTubePlayerView = (YouTubePlayerView) findViewById(R.id.youtube_player);
        youTubePlayerView.initialize(API_KEY, this);

    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult result) {
        Toast.makeText(this, "Failured to Initialize!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player, boolean wasRestored) {
        /** add listeners to YouTubePlayer instance **/
        player.setPlayerStateChangeListener(playerStateChangeListener);
        player.setPlaybackEventListener(playbackEventListener);

        /** Start buffering **/
        if (!wasRestored) {
            String videoId = getIntent().getStringExtra(VIDEO_ID);
            player.cueVideo(videoId);
        }
    }

    private YouTubePlayer.PlaybackEventListener playbackEventListener = new YouTubePlayer.PlaybackEventListener() {

        @Override
        public void onBuffering(boolean arg0) {
        }

        @Override
        public void onPaused() {
        }

        @Override
        public void onPlaying() {
        }

        @Override
        public void onSeekTo(int arg0) {
        }

        @Override
        public void onStopped() {
        }

    };

    private YouTubePlayer.PlayerStateChangeListener playerStateChangeListener = new YouTubePlayer.PlayerStateChangeListener() {

        @Override
        public void onAdStarted() {
        }

        @Override
        public void onError(YouTubePlayer.ErrorReason arg0) {
        }

        @Override
        public void onLoaded(String arg0) {
        }

        @Override
        public void onLoading() {
        }

        @Override
        public void onVideoEnded() {
        }

        @Override
        public void onVideoStarted() {
        }
    };





    /*ListView lv2;*/
    Video2 videoObj2;
    VideoAdapter2 adp2;
    Gson gson;
    /*private String videoId;

    private static final String VIDEOID = "VIDEOID";

    public static void start(Context context, String videoId) {

        Intent intent = new Intent(context, videoActivity.class);
        intent.putExtra(VIDEOID, videoId);
        context.startActivity(intent);


    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);







        /*lv2 = (ListView) findViewById(R.id.listvideo2);
        videoId = getIntent().getStringExtra(VIDEOID);
        requestData2(videoId);


    }



    public String requestData2(String videoIdf) {

        String videoId2 = videoIdf.replaceAll("\\s","+");
        String query="https://www.googleapis.com/youtube/v3/videos?id="+videoId2+"&key="+Constants.API_KEY+"&fields=items(id,snippet(description,channelId,title,categoryId),statistics)&part=snippet,statistics";

        StringRequest request = new StringRequest(query, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Results", response);

                String httpget2 = new String(response);
                gson = new Gson();
                videoObj2 = gson.fromJson(httpget2, Video2.class);

                Log.d("Info", httpget2);
                adp2 = new VideoAdapter2(videoActivity.this, videoObj2.getItems());
                lv2.setAdapter(adp2);






            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError response) {
//                Log.e("Results",response.getMessage());
            }
        });
        Volley.newRequestQueue(this).add(request);


        return videoIdf;*/


}



